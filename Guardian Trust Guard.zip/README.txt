
READ ME

---------------------------------------------------------
---------------------------------------------------------

You must close "Call of Duty" BEFORE using  this software

---------------------------------------------------------
---------------------------------------------------------


Guardian utilizes RiCOCHET's advanced usermode anti-cheat logic to
proactively identify factors negatively impacting your trust score.
These security checks are critical requirements enforced by most
anti-cheat systems, ensuring your PC operates within a secure
environment.

In addition to essential security scans, Guardian actively searches
your system for suspicious programs that may adversely affect your
trust score. It clearly identifies these potential issues, providing
actionable insights to help you mitigate risks and improve your
standing.

Furthermore, Guardian thoroughly scans hundreds of files specifically
monitored by RiCOCHET, giving you a comprehensive understanding of your
current status within the RiCOCHET anti-cheat framework. This helps
genuine players avoid unintended placement in limited matchmaking pools
due to trust-related issues.

To maintain the highest level of integrity and avoid any potential
conflicts, we require that Call of Duty be closed while Guardian is
running. Our program leverages state-of-the-art technology, mirroring
the sophisticated logic of RiCOCHET Anti-Cheat to ensure your gaming
environment is perfectly optimized. This ensures seamless operation and
the best experience for you. Thank you for helping us maintain a secure
gaming environment!

Please ensure Call of Duty is completely closed before running Guardian
to allow for a proper and thorough analysis.

If you are not sure if Call of Duty is currently running, please close
this software and close Call of Duty. You can check if Call of Duty is
closed by looking at your Task Manager.

By running Guardian, you confirm the following:

- Call of Duty is fully closed. This is critical to ensure Guardian
  can provide a complete and correct assessment.
- Your account is at least three months old, you have not received a
  permanent ban, and you are not actively running or injecting cheat
  software into the game.

Additionally, when you log into Call of Duty, RiCOCHET assigns an
account trust score based on various gameplay factors such as your
overall playstyle, accuracy, shooting patterns, kills-to-deaths ratio,
consistency, and behavior within matches. This gameplay-based trust
score is combined with Guardian's assessment to determine your overall
risk factor while playing Call of Duty.

Guardian ensures your system operates within a secure and trusted
environment, but remember, your actual in-game performance and behavior
are also significant contributors to your overall trust score.

Guardian is dedicated to enhancing your gaming experience, empowering
honest players by protecting your integrity and improving your
matchmaking potential.

Guardian puts you in the best possible position before launching
Call of Duty.